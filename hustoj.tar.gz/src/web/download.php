<?php
////////////////////////////Common head
require_once('./include/db_info.inc.php');
require_once('./include/my_func.inc.php');
$id = intval($_GET['id']??"0");
if(empty($OJ_DATA)) die();
$zipname=$OJ_DATA."/".$id."/sample.zip";
if(file_exists($zipname)){
    header('Content-Type: application/zip;charset=utf8');
    header('Content-disposition: attachment; filename=Sample_' . date('Y-m-d') . '.zip');
    header('Content-Length: ' . filesize($zipname));
    readfile($zipname);
    die();
}
if ((!isset($OJ_DOWNLOAD)) || !$OJ_DOWNLOAD) {
    $view_errors = "Download Disabled!";
    require("template/" . $OJ_TEMPLATE . "/error.php");
    exit(0);

}
if($coin<=0){
        $view_errors = "<h2> $MSG_NO_COIN </h2>";
        require("template/" . $OJ_TEMPLATE . "/error.php");
        exit(0);
}
$sid = intval($_GET['sid']);
$name = basename($_GET['name'], ".out");
$name = basename($name, ".in");
$sql = "select problem_id,contest_id,user_id from solution where solution_id=?";
$data = pdo_query($sql, $sid);
//var_dump($sql);
if (!empty($data)) {
    $row = $data[0];
    $pid = $row[0];
    if (problem_locked($pid, 2)) {
        $view_errors = "<h2> $MSG_NOIP_WARNING </h2>";
        require("template/" . $OJ_TEMPLATE . "/error.php");
        exit(0);
    }
    $cid = $row[1];
    $uid = $row[2];
    if (!(isset($_SESSION[$OJ_NAME . '_' . 'user_id']) && $uid == $_SESSION[$OJ_NAME . '_' . 'user_id']
        || isset($_SESSION[$OJ_NAME . '_' . 'administrator'])
    )) {
        $view_errors = "not your submission";
        require("template/" . $OJ_TEMPLATE . "/error.php");
        exit(0);
    }
    if (isset($OJ_NOIP_KEYWORD) && $OJ_NOIP_KEYWORD) {
        $now = date('Y-m-d H:i', time());
        $sql = "select 1 from `contest` where contest_id=? and `start_time` < ? and `end_time` > ? and `title` like ?";
        $rrs = pdo_query($sql, $cid, $now, $now, "%$OJ_NOIP_KEYWORD%");
        $flag = count($rrs) > 0;
        if ($flag) {
            $view_errors = "<h2> $MSG_NOIP_WARNING </h2>";
            require("template/" . $OJ_TEMPLATE . "/error.php");
            exit(0);
        }

    }
    $infile = "$OJ_DATA/$pid/$name.in";
    $outfile = "$OJ_DATA/$pid/$name.out";

    $zipname = tempnam(sys_get_temp_dir(), 'download.zip');
    $zip = new ZipArchive();

    if ($zip->open($zipname, ZIPARCHIVE::CREATE) !== TRUE) {
        exit ('无法打开文件，或者文件创建失败');
    }
    $files = [$infile, $outfile];

    foreach ($files as $file) {
	if(!file_exists($file)) continue;
        $entryname = basename($file);
	if(!($zip->addFile($file, $entryname, 0,0, ZipArchive::FL_OVERWRITE | ZipArchive::FL_ENC_UTF_8))){
		echo htmlentities($infile);
		exit();
	}
    }
    $zip->close();
    header('Content-Type: application/zip;charset=utf8');
    header('Content-disposition: attachment; filename=' . $name . date('Y-m-d') . '.zip');
    header('Content-Length: ' . filesize($zipname));
    ob_end_flush();
    readfile($zipname);
    unlink($zipname);
    die();
}
?>
