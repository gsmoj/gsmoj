ace.define("ace/snippets/logiql",[], function(require, exports, module) {
"use strict";

exports.snippetText = "";
exports.scope = "logiql";

});
                (function() {
                    ace.require(["ace/snippets/logiql"], function(m) {
                        if (typeof module == "object" && typeof exports == "object" && module) {
                            module.exports = m;
                        }
                    });
                })();
            